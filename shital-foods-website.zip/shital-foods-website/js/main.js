/* SF Soda · Shital Foods — main script (cart, flavors, gallery, offers, sliders) */
const VIDEOS=[
 {v:'vN',t:'tN',label:'SF Soda — Refreshingly Pure',cat:'events',wide:1},
 {v:'v2',t:'t2',label:'Orange — असली ताज़गी',cat:'products'},
 {v:'v5',t:'t5',label:'Happy Party — SF Soda',cat:'events'},
 {v:'v1',t:'t1',label:'Taste of Refreshment',cat:'events'}];
const IMAGES=[
 {m:'n2Blue2',label:'Blueberry Soda — 200ml',cat:'products'},{m:'m3Guava',label:'Guava Soda — 300ml',cat:'products'},{m:'m3Pine',label:'Pineapple Soda — 300ml',cat:'products'},{m:'m3Ginger',label:'Ginger Soda — 300ml',cat:'products'},{m:'m3Straw',label:'Strawberry Soda — 300ml',cat:'products'},{m:'m3Imli',label:'Imli Soda — 300ml',cat:'products'},{m:'m3Mint',label:'Mint Soda — 300ml',cat:'products'},{m:'m3Anaar',label:'Anaar Soda — 300ml',cat:'products'},
 {m:'m3Mango',label:'Mango Soda — 300ml',cat:'products'},{m:'m3Blue',label:'Blueberry Soda — 300ml',cat:'products'},{m:'m3Orange',label:'Orange Soda — 300ml',cat:'products'},{m:'m3Lemon',label:'Lemon Soda — 300ml',cat:'products'},{m:'m3Jeera',label:'Jeera Masala — 300ml',cat:'products'},
 {m:'fam',label:'The SF Soda Family',cat:'products'},
 {m:'trioL',label:'Discover the Taste of India',cat:'products'},
 {m:'trioP',label:'Jeera Masala · Lemon · Orange',cat:'products'},
 {m:'blk',label:'Jeera Masala & Orange',cat:'products'},
 {m:'lemS',label:'SF Lemon Soda',cat:'products'},
 {m:'lemP',label:'Refreshingly Pure',cat:'products'},
 {m:'range',label:'200ml to 2 Liter Range',cat:'products'},
 {m:'p1',label:'Our Bottles — 200ml',cat:'products'},
 {m:'p2',label:'Strong Flavour, Super Fresh',cat:'products'}];
const GALLERY_ITEMS=[...IMAGES.map(i=>({kind:'img',...i})),...VIDEOS.map(v=>({kind:'vid',...v}))];
(function(){
 const h=document.getElementById('heroPhoto'); if(h) h.src=MEDIA.trioP;
 const ci=document.getElementById('collImg'); if(ci) ci.src=MEDIA.trioL;
 const BG={story:'trioL',offers:'blk',gallery:'lemP',nutrition:'lemS',franchise:'trioL'}; for(const k in BG) document.documentElement.style.setProperty('--bg-'+k,'url('+MEDIA[BG[k]]+')');
 const r=document.getElementById('rangeImg'); if(r) r.src=MEDIA.range;
 const g=document.getElementById('showcaseGrid');
 if(g) g.innerHTML=VIDEOS.map(v=>`<div class="sc-card${v.wide?' wide':''}"><video src="${MEDIA[v.v]}" poster="${MEDIA[v.t]}" controls muted loop playsinline preload="none"></video><div class="sc-cap">${v.label}</div></div>`).join('');
})();
const IMG200={1:'cJ',2:'cL',3:'cO',5:'n2Mango',6:'xAnaar',7:'xMint',8:'xImli',9:'xStraw',11:'xGinger',14:'n2Blue',15:'xPine',16:'n2Guava'};
const IMG300={1:'m3Jeera',2:'m3Lemon',3:'m3Orange',5:'m3Mango',6:'m3Anaar',7:'m3Mint',8:'m3Imli',9:'m3Straw',11:'m3Ginger',14:'m3Blue',15:'m3Pine',16:'m3Guava'};
const getImg=(id,sz)=>sz==='300ml'?(IMG300[id]||IMG200[id]):(IMG200[id]||IMG300[id]);
const REAL_IMG=IMG200;

const FLAVORS = [
  {id:1,emoji:'🌾',name:'Jeera Soda',nameHi:'जीरा सोडा',desc:'Authentic cumin fizz with a spicy, tangy kick',cat:'classic',bg:'#FEF3C7',badge:'hot',p200:15,p300:25},
  {id:2,emoji:'🍋',name:'Nimbu Soda',nameHi:'निम्बू सोडा',desc:'Fresh lemon — the ultimate summer cooler',cat:'classic',bg:'#FEFCE8',badge:'hot',p200:15,p300:25},
  {id:3,emoji:'🍊',name:'Orange Soda',nameHi:'ऑरेंज सोडा',desc:'Bursting with real orange citrus flavor',cat:'fruit',bg:'#FFF7ED',badge:'',p200:15,p300:25},
  {id:5,emoji:'🥭',name:'Mango Soda',nameHi:'आम सोडा',desc:"Vidarbha's finest Alphonso mango essence",cat:'fruit',bg:'#FFFBEB',badge:'hot',p200:15,p300:25},
  {id:6,emoji:'🫐',name:'Pomegranate Soda',nameHi:'अनार सोडा',desc:'Sweet-tart pomegranate — rich & refreshing',cat:'fruit',bg:'#FFF5F5',badge:'new',p200:15,p300:25},
  {id:7,emoji:'🌿',name:'Mint Soda',nameHi:'मिंट सोडा',desc:'Cool fresh mint — beats the heat instantly',cat:'special',bg:'#F0FDF4',badge:'',p200:15,p300:25},
  {id:8,emoji:'🤎',name:'Tamarind Soda',nameHi:'इमली सोडा',desc:'Tangy tamarind — bold, unique, unforgettable',cat:'special',bg:'#FEF9EE',badge:'new',p200:15,p300:25},
  {id:9,emoji:'🍓',name:'Strawberry Soda',nameHi:'स्ट्रॉबेरी सोडा',desc:'Sweet red strawberry magic in a bottle',cat:'fruit',bg:'#FFF5F7',badge:'love',p200:15,p300:25},
  {id:11,emoji:'🫚',name:'Ginger Soda',nameHi:'अदरक सोडा',desc:'Warming ginger spice for cool evenings',cat:'classic',bg:'#FEFCE8',badge:'',p200:15,p300:25},
  {id:14,emoji:'🫐',name:'Blueberry Soda',nameHi:'ब्लूबेरी सोडा',desc:'Rich, juicy blueberry — cool, fruity and fizzy',cat:'fruit',bg:'#EEF2FF',badge:'new',p200:15,p300:25},
  {id:15,emoji:'🍍',name:'Pineapple Soda',nameHi:'पाइनएप्पल सोडा',desc:'Tropical pineapple — bright, fizzy, fun',cat:'fruit',bg:'#FEFCE8',badge:'',p200:15,p300:25},
  {id:16,emoji:'🍈',name:'Guava Soda',nameHi:'अमरूद सोडा',desc:'Sweet, tropical guava — a desi favourite, chilled',cat:'fruit',bg:'#F0FDF4',badge:'new',p200:15,p300:25},
];



const INGREDIENTS = [
  {emoji:'🍋',name:'Lemon',benefit:'Zesty'},
  {emoji:'🌾',name:'Cumin',benefit:'Spicy & Tangy'},
  {emoji:'🌹',name:'Rose Petals',benefit:'Floral'},
  {emoji:'🥭',name:'Mango',benefit:'Sweet & Fruity'},
  {emoji:'🌿',name:'Mint',benefit:'Cool Taste'},
  {emoji:'🫐',name:'Pomegranate',benefit:'Sweet-Tart'},
  {emoji:'🥥',name:'Coconut',benefit:'Creamy'},
  {emoji:'🍯',name:'Sugar',benefit:'Sweetener'},
  {emoji:'💧',name:'Purified Water',benefit:'RO Purified'},
  {emoji:'🫧',name:'Food-grade CO₂',benefit:'Fizz'},
  {emoji:'🧂',name:'Black Salt',benefit:'Tangy Salty'},
  {emoji:'🫚',name:'Ginger',benefit:'Zingy'},
];

const OFFERS = [
  {emoji:'🎊',discount:'BUY 5 GET 1',title:'Weekend Splash Deal',sub:'Buy any 5 bottles, get 1 FREE!',gradient:'linear-gradient(135deg,#E8751A,#B85A0A)',until:'monthEnd',code:'SPLASH6',wa:'Hello! I want the SPLASH6 offer.'},
  {emoji:'🌞',discount:'20% OFF',title:'Monthly Special',sub:'20% off on all 300ml bottles',gradient:'linear-gradient(135deg,#F59E47,#E8751A)',until:'monthEnd',code:'SUMMER20',wa:'Hello! I want the SUMMER20 offer.'},
  {emoji:'🎂',discount:'₹50 OFF',title:'Birthday Bulk Order',sub:'Order 24+ bottles — get ₹50 off',gradient:'linear-gradient(135deg,#ec4899,#be185d)',validity:'Ongoing',code:'BDAY50',wa:'Hello! I want to place a birthday bulk order.'},
  {emoji:'🤝',discount:'15% OFF',title:'Franchise Welcome',sub:'First month 15% off for new partners',gradient:'linear-gradient(135deg,#2D6A4F,#1B4332)',validity:'Ongoing',code:'PARTNER15',wa:'Hello! I am interested in the franchise offer.'},
];

const COMBOS = [
  {emoji:'🥤🥤🥤',name:'Trio Pack',desc:'3 bottles of your choice (any flavors)',items:'3 × 200ml or 300ml',price:40,oldPrice:52,popular:false,wa:'Hello! I want the Trio Pack combo.'},
  {emoji:'🥤🥤🥤🥤🥤🥤',name:'Family Pack',desc:'6 assorted bottles — best value for families',items:'6 × 200ml',price:80,oldPrice:90,popular:true,wa:'Hello! I want the Family Pack combo.'},
  {emoji:'🎁',name:'Party Pack',desc:'12 bottles — perfect for events & functions',items:'12 × 200ml (assorted)',price:150,oldPrice:180,popular:false,wa:'Hello! I want the Party Pack combo.'},
  {emoji:'💎',name:'Mega Pack',desc:'24 bottles — for big celebrations',items:'24 × 200ml (all flavors)',price:280,oldPrice:360,popular:false,wa:'Hello! I want the Mega Pack combo.'},
];

// =================== CART ===================
let cart = (function(){try{const s=JSON.parse(localStorage.getItem('sf_soda_cart')||'[]');return s.map(x=>{const f=FLAVORS.find(f=>f.id===x.id);if(!f||!['200ml','300ml'].includes(x.size))return null;return {id:f.id,name:f.name,emoji:f.emoji,size:x.size,price:x.size==='200ml'?f.p200:f.p300,qty:Math.max(1,x.qty|0)}}).filter(Boolean)}catch(e){return []}})();
let selSizes = {};

function addToCart(id) {
  const f = FLAVORS.find(x => x.id === id);
  const size = selSizes[id] || '200ml';
  const price = size === '200ml' ? f.p200 : f.p300;
  const ex = cart.find(c => c.id === id && c.size === size);
  if (ex) ex.qty++;
  else cart.push({id, name: f.name, emoji: f.emoji, size, price, qty: 1});
  updateCart();
  showToast(`✅ ${f.emoji} ${f.name} added to cart!`, 'success');
}

function setSize(id, size) {
  selSizes[id] = size;
  renderFlavors('homeFlavors', FLAVORS.concat(FLAVORS));
  renderFlavors('allFlavors', FLAVORS);
}

function updateCart() {
  try{localStorage.setItem('sf_soda_cart',JSON.stringify(cart.map(c=>({id:c.id,size:c.size,qty:c.qty}))))}catch(e){}
  const count = cart.reduce((a,c)=>a+c.qty,0);
  document.getElementById('cartBadge').textContent = count;
  const total = cart.reduce((a,c)=>a+c.price*c.qty,0);
  document.getElementById('cartTotal').textContent = '₹'+total;
  const body = document.getElementById('cartBody');
  if (!cart.length) { body.innerHTML = '<div class="cart-empty-state"><span class="ei">🥤</span><p>Your cart is empty.<br>Explore our flavors!</p></div>'; return; }
  body.innerHTML = cart.map((c,i) => `
    <div class="citem">
      <span class="citem-e">${c.emoji}</span>
      <div class="citem-info">
        <div class="citem-name">${c.name}</div>
        <div class="citem-price">${c.size} · ₹${c.price} × ${c.qty} = ₹${c.price*c.qty}</div>
      </div>
      <div class="cqty">
        <button class="cqbtn" onclick="changeQty(${i},-1)">−</button>
        <span class="cqn">${c.qty}</span>
        <button class="cqbtn" onclick="changeQty(${i},1)">+</button>
      </div>
    </div>`).join('');
}

function changeQty(i, d) { cart[i].qty += d; if (cart[i].qty <= 0) cart.splice(i,1); updateCart(); }
function toggleCart() { document.getElementById('cartDrawer').classList.toggle('open'); document.getElementById('cartOverlay').classList.toggle('open'); }

function waOrder() {
  if (!cart.length) { showToast('❌ Cart is empty!', 'error'); return; }
  const total = cart.reduce((a,c)=>a+c.price*c.qty,0);
  let msg = '🥤 *Shital Foods Order*\n\n';
  cart.forEach(c => { msg += `• ${c.emoji} ${c.name} (${c.size}) × ${c.qty} = ₹${c.price*c.qty}\n`; });
  msg += `\n💰 *Total: ₹${total}*\n\n📍 Near Cinema Talkies, Ward No.8, Nagbhid`;
  window.open(`https://wa.me/919764026807?text=${encodeURIComponent(msg)}`, '_blank');
}

// =================== RENDER ===================
function renderFlavors(containerId, list) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = list.map(f => {
    const sz = selSizes[f.id] || '200ml', im = getImg(f.id,sz);
    return `<div class="flavor-card">
      <div class="flavor-top${im?' has-photo':''}" style="background:${f.bg};${im?`--b:url(${MEDIA[im]})`:''}">
        ${f.badge ? `<div class="flavor-badge badge-${f.badge}">${f.badge==='hot'?'🔥 HOT':f.badge==='new'?'🆕 NEW':'💖 LOVE'}</div>` : ''}
        <div class="flavor-bg-circle" style="background:${f.bg.replace(')',',0.5)')}"></div>
        ${im?`<img class="flavor-photo" src="${MEDIA[im]}" alt="${f.name}" onclick="openFlavor(${f.id})">`:`<span class="flavor-emoji" onclick="openFlavor(${f.id})">${f.emoji}</span>`}
      </div>
      <div class="flavor-bot">
        <div class="flavor-name" onclick="openFlavor(${f.id})" style="cursor:pointer">${f.name}</div>
        <div class="flavor-name-hi">${f.nameHi}</div>
        <div class="flavor-sizes">
          <div class="fsize${sz==='200ml'?' sel':''}" onclick="setSize(${f.id},'200ml')">200ml ₹${f.p200}</div>
          <div class="fsize${sz==='300ml'?' sel':''}" onclick="setSize(${f.id},'300ml')">300ml ₹${f.p300}</div>
        </div>
        <button class="fadd" onclick="addToCart(${f.id})">Add to Cart 🛒</button>
      </div>
    </div>`;
  }).join('');
}

function filterFlavors(cat, btn) {
  document.querySelectorAll('.ffilter').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const filtered = cat === 'all' ? FLAVORS : FLAVORS.filter(f => f.cat === cat);
  renderFlavors('allFlavors', filtered);
}

function renderGallery(cat='all') {
  const el = document.getElementById('galleryGrid');
  if (!el) return;
  const filtered = cat === 'all' ? GALLERY_ITEMS : GALLERY_ITEMS.filter(g => g.cat === cat);
  el.innerHTML = (window.GV=filtered).map((g,i) => `
    <div class="gallery-item ${g.kind==='vid'?'vid':''}" data-cat="${g.cat}" onclick="openViewer(${i})">
      ${g.kind==='vid'?`<video src="${MEDIA[g.v]}" poster="${MEDIA[g.t]}" muted loop playsinline preload="none" onmouseenter="this.play()" onmouseleave="this.pause()"></video><span class="gv-badge">▶</span>`:`<img src="${MEDIA[g.m]}" alt="${g.label}">`}
      <div class="gallery-overlay" style="pointer-events:none"><span class="gallery-caption">${g.label}</span></div>
    </div>`).join('');
}

function filterGallery(cat, btn) {
  document.querySelectorAll('.gtab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderGallery(cat);
}

/* OFFER VALIDITY — how to set "until" for each offer in OFFERS:
   until:'monthEnd'      -> always shows the last date of the CURRENT month (auto-updates every month)
   until:'2026-12-31'    -> fixed date (YYYY-MM-DD); the offer hides itself automatically after that date
   (no until)            -> uses validity:'Ongoing' text */
function offerValidity(o){
  if(o.until==='monthEnd'){
    const t=new Date(), e=new Date(t.getFullYear(),t.getMonth()+1,0);
    return e.toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});
  }
  if(/^\d{4}-\d{2}-\d{2}$/.test(o.until||'')){
    return new Date(o.until+'T00:00:00').toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});
  }
  return o.validity||'Ongoing';
}
function offerActive(o){
  if(/^\d{4}-\d{2}-\d{2}$/.test(o.until||'')) return new Date(o.until+'T23:59:59')>=new Date();
  return true;
}
function renderOffers() {
  const el = document.getElementById('offersGrid');
  if (!el) return;
  el.innerHTML = OFFERS.filter(offerActive).map(o => `
    <div class="offer-card">
      <div class="offer-top" style="background:${o.gradient}">
        <span class="offer-emoji">${o.emoji}</span>
        <div class="offer-discount">${o.discount}</div>
        <div class="offer-title">${o.title}</div>
        <div class="offer-sub">${o.sub}</div>
      </div>
      <div class="offer-bot">
        <div class="offer-validity"><span class="offer-validity-label">Valid till</span><span class="offer-validity-date">${offerValidity(o)}</span></div>
        <div class="offer-code"><div class="offer-code-label">Use Code</div><div class="offer-code-value">${o.code}</div></div>
        <button class="offer-wa-btn" onclick="window.open('https://wa.me/919764026807?text=${encodeURIComponent('Hello! I want to use offer code '+o.code+'. '+o.wa)}','_blank')">📱 Claim on WhatsApp</button>
      </div>
    </div>`).join('');
  const el2 = document.getElementById('comboPacks');
  if (!el2) return;
  el2.innerHTML = COMBOS.map(c => `
    <div class="combo-card">
      ${c.popular ? '<div class="combo-popular">⭐ Most Popular</div>' : ''}
      <span class="combo-items">${c.emoji}</span>
      <div class="combo-name">${c.name}</div>
      <div class="combo-desc">${c.desc}<br><small style="opacity:0.6">${c.items}</small></div>
      <div class="combo-price-row"><span class="combo-price">₹${c.price}</span><span class="combo-old-price">₹${c.oldPrice}</span></div>
      <button class="combo-btn" onclick="window.open('https://wa.me/919764026807?text=${encodeURIComponent(c.wa)}','_blank')">Order This Pack 🛒</button>
    </div>`).join('');
}

function renderIngredients() {
  const el = document.getElementById('ingGrid');
  if (!el) return;
  el.innerHTML = INGREDIENTS.map(i => `
    <div class="ing-card"><span class="ing-emoji">${i.emoji}</span><div class="ing-name">${i.name}</div><div class="ing-benefit">✅ ${i.benefit}</div></div>`).join('');
}

// =================== NAVIGATION ===================
const PAGE_URL={"home": "index.html", "products": "flavors.html", "story": "story.html", "offers": "offers.html", "gallery": "gallery.html", "nutrition": "nutrition.html", "franchise": "franchise.html", "contact": "contact.html", "member": "member.html", "privacy": "privacy.html", "terms": "terms.html"};
function showPage(page) { window.location.href = PAGE_URL[page] || 'index.html'; }

function toggleMobileNav() {
  document.getElementById('mobileNav').classList.toggle('open');
}

function submitContact() {
  const f=[...document.getElementById('page-contact').querySelectorAll('.cf-input')].map(x=>x.value.trim());
  const [fn,ln,ph,em,sub,msg]=f;
  if(!fn||!ph||!msg){showToast('⚠️ कृपया नाम, फोन और संदेश भरें','error');return}
  const body=`SF Soda / Shital Foods
Name: ${fn} ${ln}
Phone: ${ph}${em?`
Email: ${em}`:''}
Subject: ${sub}
Message: ${msg}`;
  window.location.href='sms:+919764026807?&body='+encodeURIComponent(body);
  showToast('📱 SMS ऐप खुल रहा है — Send दबाएँ','success');
}

function showToast(msg, type='success') {
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = `toast show ${type}`;
  setTimeout(() => t.classList.remove('show'), 3000);
}

// =================== INIT ===================
// Render marquee
const marqueeItems = [['Jeera','Jeera Soda'],['Lemon','Nimbu Soda'],['Orange','Orange Soda'],['Mango','Mango Soda'],['Blue','Blueberry Soda'],['Anaar','Anaar Soda'],['Mint','Mint Soda'],['Imli','Imli Soda'],['Straw','Strawberry Soda'],['Ginger','Ginger Soda'],['Pine','Pineapple Soda'],['Guava','Guava Soda']];
const track = document.getElementById('marqueeTrack');
if (track) {
  const double = [...marqueeItems, ...marqueeItems];
  track.innerHTML = double.map(i => `<span class="marquee-item"><img class="mq-fruit" src="${MEDIA['fr'+i[0]]}" alt="${i[1]}">${i[1]}</span>`).join('');
}

// Render initial flavors
renderFlavors('homeFlavors', FLAVORS.concat(FLAVORS));
renderFlavors('allFlavors', FLAVORS);
renderGallery(); renderOffers(); renderIngredients(); updateCart();

// Navbar scroll
window.addEventListener('scroll', () => {
  const nav = document.getElementById('main-nav');
  nav.classList.toggle('scrolled', window.scrollY > 50);
  document.getElementById('backTop').classList.toggle('show', window.scrollY > 400);
});

// Cursor
const cursor = document.getElementById('cursor');
const ring = document.getElementById('cursorRing');
document.addEventListener('mousemove', e => {
  cursor.style.left = e.clientX + 'px'; cursor.style.top = e.clientY + 'px';
  setTimeout(() => { ring.style.left = e.clientX + 'px'; ring.style.top = e.clientY + 'px'; }, 80);
});
document.querySelectorAll('a,button,[onclick]').forEach(el => {
  el.addEventListener('mouseenter', () => { cursor.style.width='18px';cursor.style.height='18px';ring.style.width='55px';ring.style.height='55px'; });
  el.addEventListener('mouseleave', () => { cursor.style.width='12px';cursor.style.height='12px';ring.style.width='40px';ring.style.height='40px'; });
});

// Reveal on scroll
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

// Page loader
(function(){const l=document.getElementById('pageLoader');let seen=false;try{seen=sessionStorage.getItem('sf_loaded')==='1';sessionStorage.setItem('sf_loaded','1')}catch(e){}
if(seen){l.style.display='none'}else{setTimeout(()=>l.classList.add('done'),1600)}})();

(function(){
const RS=[['Pine','Pineapple Soda','पाइनएप्पल सोडा','fruity'],['Straw','Strawberry Soda','स्ट्रॉबेरी सोडा','fruity'],['Imli','Imalee Soda','इमली सोडा','chat'],['Mint','Mint Soda','मिंट सोडा','cool'],['Ginger','Ginger Soda','अदरक सोडा','chat'],['Anaar','Anaar Soda','अनार सोडा','fruity']];
const CH=[['all','सब'],['chat','चटपटा'],['fruity','फ्रूटी'],['cool','ठंडक']];
let cur='all',list=RS.slice(),i=0,t;
const $=id=>document.getElementById(id); if(!$('rsStage'))return;
$('rsChips').innerHTML=CH.map(c=>`<button class="rs-chip${c[0]==='all'?' on':''}" data-c="${c[0]}">${c[1]}</button>`).join('');
function thumbs(){$('rsThumbs').innerHTML=list.map((r,j)=>`<button class="rs-th" data-j="${j}"><img src="${MEDIA['x'+r[0]]}" alt="${r[1]}"></button>`).join('')}
function show(n){i=n;const r=list[n],im=$('rsImg');im.classList.add('out');setTimeout(()=>{im.src=MEDIA['s'+r[0]];im.alt=r[1];im.classList.remove('out')},300);
$('rsNo').textContent='No. '+String(n+1).padStart(2,'0');$('rsName').textContent=r[1];$('rsHi').textContent=r[2];
document.querySelectorAll('.rs-th').forEach((e,j)=>e.classList.toggle('on',j===n))}
function auto(){clearInterval(t);t=setInterval(()=>show((i+1)%list.length),4500)}
$('rsChips').onclick=e=>{const c=e.target.dataset.c;if(!c)return;cur=c;list=RS.filter(r=>c==='all'||r[3].includes(c));document.querySelectorAll('.rs-chip').forEach(b=>b.classList.toggle('on',b.dataset.c===c));thumbs();show(0);auto()};
$('rsThumbs').onclick=e=>{const b=e.target.closest('.rs-th');if(b){show(+b.dataset.j);auto()}};
$('rsStage').onmousemove=e=>{const r=e.currentTarget.getBoundingClientRect();$('rsImg').style.setProperty('--px',((.5-(e.clientX-r.left)/r.width)*8)+'%');$('rsImg').style.setProperty('--py',((.5-(e.clientY-r.top)/r.height)*8)+'%')};
$('rsStage').onmouseenter=()=>clearInterval(t);$('rsStage').onmouseleave=auto;
window.rsShow=show;thumbs();show(0);auto();
})();


const CATN={classic:'Classic · क्लासिक',fruit:'Fruity · फ्रूटी',special:'Special · स्पेशल'};
let popId=0,popSz='200ml';
function drawPop(){const f=FLAVORS.find(x=>x.id===popId),im=getImg(popId,popSz);
 document.getElementById('popImg').src=im?MEDIA[im]:'';document.getElementById('popImg').style.display=im?'':'none';
 document.getElementById('popInfo').innerHTML=`<div class="section-eyebrow">SF Soda · ${CATN[f.cat]||''}</div><h3>${f.name}</h3><div class="pop-hi">${f.nameHi}</div><p>${f.desc}.</p>
 <div class="pop-tags"><span>Strong Flavour</span><span>Super Fresh</span><span>Serve Chilled ❄️</span></div>
 <div class="pop-sizes"><div class="fsize${popSz==='200ml'?' sel':''}" onclick="popSz='200ml';drawPop()">200ml ₹${f.p200}</div><div class="fsize${popSz==='300ml'?' sel':''}" onclick="popSz='300ml';drawPop()">300ml ₹${f.p300}</div></div>
 <button class="fadd" style="width:100%" onclick="selSizes[${f.id}]=popSz;addToCart(${f.id});setSize(${f.id},popSz)">Add to Cart 🛒</button>`}
function openFlavor(id){popId=id;popSz=selSizes[id]||'200ml';drawPop();const p=document.getElementById('pop');p.classList.remove('lb');p.classList.add('on')}
function openLB(src){document.getElementById('popImg').style.display='';document.getElementById('popImg').src=src;const p=document.getElementById('pop');p.classList.add('lb','on')}
function closePop(){document.getElementById('pop').classList.remove('on')}
document.getElementById('pop').addEventListener('click',e=>{if(e.target.id==='pop')closePop()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closePop()});
const RSID={Pine:15,Straw:9,Imli:8,Mint:7,Ginger:11,Anaar:6};
document.addEventListener('click',e=>{const t=e.target;
 if(t.matches('.coll-sec img,.range-sec img,.hero-photo'))return openLB(t.src);
 if(t.closest('#rsStage')){const k=(document.getElementById('rsImg').src.length&&Object.keys(RSID).find(k=>new URL(MEDIA['s'+k],location.href).href===document.getElementById('rsImg').src));if(k)openFlavor(RSID[k])}});


let gvI=0,gvT=null,gvAuto=false;
function gvDraw(){const g=GV[gvI],st=document.getElementById('gvStage');
 st.innerHTML=g.kind==='vid'?`<video src="${MEDIA[g.v]}" poster="${MEDIA[g.t]}" controls autoplay playsinline></video>`:`<img src="${MEDIA[g.m]}" alt="${g.label}">`;
 const v=st.querySelector('video'); if(v)v.onended=()=>{if(gvAuto)gvStep(1)};
 document.getElementById('gvCap').textContent=g.label;document.getElementById('gvCnt').textContent=(gvI+1)+' / '+GV.length;
 document.getElementById('gvStrip').innerHTML=GV.map((x,j)=>`<img class="${j===gvI?'on':''}" src="${MEDIA[x.m||x.t]}" onclick="gvI=${j};gvDraw()">`).join('');
 const a=document.querySelector('#gvStrip img.on');if(a)a.scrollIntoView({inline:'center',block:'nearest'});
 clearTimeout(gvT);if(gvAuto&&g.kind!=='vid')gvT=setTimeout(()=>gvStep(1),3500)}
function openViewer(i){gvI=i;document.getElementById('gv').classList.add('on');gvDraw()}
function gvStep(d){gvI=(gvI+d+GV.length)%GV.length;gvDraw()}
function gvToggle(){gvAuto=!gvAuto;document.getElementById('gvPlay').textContent=gvAuto?'⏸ Pause':'▶ Slideshow';gvDraw()}
function closeGV(){gvAuto=false;clearTimeout(gvT);document.getElementById('gvStage').innerHTML='';document.getElementById('gv').classList.remove('on');document.getElementById('gvPlay').textContent='▶ Slideshow'}
document.addEventListener('keydown',e=>{if(!document.getElementById('gv').classList.contains('on'))return;if(e.key==='ArrowRight')gvStep(1);if(e.key==='ArrowLeft')gvStep(-1);if(e.key==='Escape')closeGV()});
let gx=0;const gs=document.getElementById('gvStage');gs.addEventListener('touchstart',e=>gx=e.touches[0].clientX);gs.addEventListener('touchend',e=>{const d=e.changedTouches[0].clientX-gx;if(Math.abs(d)>50)gvStep(d<0?1:-1)});


(function(){
const EMI=window.EMI_MAP;
const RE=/(\p{Extended_Pictographic}\ufe0f?(?:\u200d\p{Extended_Pictographic}\ufe0f?)*)/gu, HAS=/\p{Extended_Pictographic}/u;
const SKIP=/^(SCRIPT|STYLE|TEXTAREA|OPTION|SELECT|TITLE|NOSCRIPT|INPUT)$/;
function conv(root){
  const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode(n){const p=n.parentNode;if(!p||SKIP.test(p.nodeName)||(p.closest&&p.closest('option,select,textarea')))return NodeFilter.FILTER_REJECT;return HAS.test(n.nodeValue)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}});
  const list=[];while(w.nextNode())list.push(w.currentNode);
  list.forEach(n=>{const t=n.nodeValue,f=document.createDocumentFragment();let last=0,ch=false;
    t.replace(RE,(m,g,i)=>{const src=EMI[m.replace(/\ufe0f/g,'')];if(!src)return m;
      f.append(t.slice(last,i));const im=new Image();im.className='em';im.src=src;im.alt=m;im.draggable=false;
      const fs=parseFloat(getComputedStyle(n.parentNode).fontSize)||16;
      if(fs>=26){im.classList.add('em-lg');im.style.animationDelay=(-Math.random()*3.5).toFixed(2)+'s'}
      f.append(im);last=i+m.length;ch=true;return m});
    if(ch){f.append(t.slice(last));n.parentNode.replaceChild(f,n)}});
}
let q=false;const mo=new MutationObserver(()=>{if(q)return;q=true;requestAnimationFrame(()=>{q=false;conv(document.body)})});
conv(document.body);mo.observe(document.body,{childList:true,subtree:true,characterData:true});
})();


(function(){
if(matchMedia('(max-width:0px)').matches)return;
const mob=()=>innerWidth<=768;
// [selector, desktop k, mobile k, mode]  k>0 = lags behind scroll, k<0 = moves ahead
const T=[['.hero-photo',.16,.07,'t'],['.hero-pattern',.3,.12,'t'],['.coll-sec img',.2,.1,'t'],
['.story-hero',.35,.2,'bg'],['.offers-hero',.35,.2,'bg'],['.gallery-hero',.35,.2,'bg'],['.nutrition-hero',.35,.2,'bg'],['.franchise-hero',.35,.2,'bg'],
['.rs-sec .section-title',.1,0,'t'],['.rs-ing',-.08,0,'t'],['.range-sec img',.07,0,'t'],
['.sc-card:nth-child(even)',.06,0,'t'],['.timeline-item:nth-child(odd) .timeline-content',.05,0,'t'],['.timeline-item:nth-child(even) .timeline-content',-.05,0,'t']];
let q=false;
function run(){q=false;const H=innerHeight,m=mob();
 T.forEach(([sel,kd,km,mode])=>{const k=m?km:kd;document.querySelectorAll(sel).forEach(el=>{
  if(!k){if(el.style.translate)el.style.translate='';return}
  const r=el.getBoundingClientRect(); if(!r.height||r.bottom<-300||r.top>H+300)return;
  const off=(r.top+r.height/2)-H/2; let v=Math.max(-90,Math.min(90,-k*off));
  if(mode==='bg')el.style.setProperty('--py',v.toFixed(1)+'px');else el.style.translate='0 '+v.toFixed(1)+'px';})});
}
const req=()=>{if(!q){q=true;requestAnimationFrame(run)}};
addEventListener('scroll',req,{passive:true});addEventListener('resize',req);setInterval(req,500);req();
})();


(function(){
const reduce=matchMedia('(max-width:0px)').matches;
/* shared infinite marquee: right->left, eases to a stop on hover, supports jump (prev/next) */
function marquee(view,track,speed,opt){
  if(!view||!track)return null; opt=opt||{};
  let pos=0,v=reduce?0:speed,target=v,jump=0,last=performance.now(),vis=true,tm;
  new IntersectionObserver(e=>{vis=e[0].isIntersecting;last=performance.now()}).observe(view);
  const hold=()=>{target=0},go=()=>{target=reduce?0:speed};
  view.addEventListener('mouseenter',hold);view.addEventListener('mouseleave',go);
  view.addEventListener('touchstart',()=>{hold();clearTimeout(tm)},{passive:true});
  view.addEventListener('touchend',()=>{tm=setTimeout(go,1600)},{passive:true});
  (function f(t){const dt=Math.min(.05,(t-last)/1000);last=t;
    if(vis){const half=track.scrollWidth/2;
      if(half>0){v+=(target-v)*Math.min(1,dt*5);const st=jump*Math.min(1,dt*8);jump-=st;pos+=st+v*dt;
        pos=((pos%half)+half)%half;track.style.transform='translate3d('+(-pos).toFixed(1)+'px,0,0)'}}
    requestAnimationFrame(f)})(last);
  return {jump:d=>{jump+=d}};
}
/* testimonials */
const tmT=document.getElementById('tmTrack'),tm=marquee(document.getElementById('tmView'),tmT,45);
const step=()=>{const c=tmT&&tmT.querySelector('.tm-card');return c?c.offsetWidth+24:400};
const pv=document.getElementById('tmPrev'),nx=document.getElementById('tmNext');
if(tm&&pv){pv.onclick=()=>tm.jump(-step());nx.onclick=()=>tm.jump(step())}
/* featured flavors */
marquee(document.getElementById('fmView'),document.getElementById('homeFlavors'),55);
/* hero slider */
const hs=document.getElementById('hsTrack');if(!hs)return;
document.querySelectorAll('#heroPhoto img[data-m]').forEach(i=>i.src=MEDIA[i.dataset.m]);
const NAMES=['🥤 Jeera Masala · ₹15','🍋 Nimbu Soda · ₹15','🍊 Orange Soda · ₹15'],N=3,dots=[...document.querySelectorAll('#hsDots i')],card=document.getElementById('hsName');
let i=0,timer,busy=false;
function mark(){const k=((i%N)+N)%N;dots.forEach((d,j)=>d.classList.toggle('on',j===k));card.style.opacity=0;setTimeout(()=>{card.textContent=NAMES[k];card.style.opacity=1},250)}
function show(n){hs.classList.remove('no-t');i=n;hs.style.transform='translateX('+(-i*100)+'%)';mark()}
function next(){if(busy)return;busy=true;show(i+1)}
function prev(){if(busy)return;busy=true;if(i===0){hs.classList.add('no-t');hs.style.transform='translateX('+(-N*100)+'%)';i=N;void hs.offsetWidth}show(i-1)}
hs.addEventListener('transitionend',()=>{busy=false;if(i>=N){hs.classList.add('no-t');i=0;hs.style.transform='translateX(0)';void hs.offsetWidth;hs.classList.remove('no-t')}});
const play=()=>{clearInterval(timer);if(!reduce)timer=setInterval(next,3600)};
const box=document.getElementById('heroPhoto');
box.addEventListener('mouseenter',()=>clearInterval(timer));box.addEventListener('mouseleave',play);
let x0=0;box.addEventListener('touchstart',e=>{x0=e.touches[0].clientX;clearInterval(timer)},{passive:true});
box.addEventListener('touchend',e=>{const d=e.changedTouches[0].clientX-x0;if(Math.abs(d)>40)(d<0?next:prev)();play()});
dots.forEach((d,j)=>d.onclick=()=>{busy=true;show(j);play()});
document.addEventListener('visibilitychange',()=>document.hidden?clearInterval(timer):play());
mark();play();
})();


(function(){
document.querySelectorAll('.hb-slide img[data-m],.cat-card img[data-m]').forEach(i=>i.src=MEDIA[i.dataset.m]);
/* hero background slideshow */
const t=document.getElementById('hbTrack');
if(t){const N=4;let i=0;
 const go=()=>{i++;t.classList.remove('no-t');t.style.transform='translateX('+(-i*100)+'%)'};
 t.addEventListener('transitionend',()=>{if(i>=N){t.classList.add('no-t');i=0;t.style.transform='translateX(0)'}});
 if(!matchMedia('(max-width:0px)').matches)setInterval(()=>{if(!document.hidden)go()},5200)}
/* category slider */
const v=document.getElementById('catView');
if(v){const step=()=>{const c=v.querySelector('.cat-card');return c.offsetWidth+21};
 document.getElementById('catPrev').onclick=()=>v.scrollBy({left:-step(),behavior:'smooth'});
 document.getElementById('catNext').onclick=()=>{const end=v.scrollLeft+v.clientWidth>=v.scrollWidth-4;end?v.scrollTo({left:0,behavior:'smooth'}):v.scrollBy({left:step(),behavior:'smooth'})};
 let down=false,sx=0,sl=0,moved=false;
 v.addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse')return;down=true;moved=false;sx=e.clientX;sl=v.scrollLeft;v.style.scrollSnapType='none';v.style.cursor='grabbing'});
 addEventListener('pointermove',e=>{if(!down)return;const d=e.clientX-sx;if(Math.abs(d)>5)moved=true;v.scrollLeft=sl-d});
 addEventListener('pointerup',()=>{if(!down)return;down=false;v.style.scrollSnapType='';v.style.cursor=''});
 v.addEventListener('click',e=>{if(moved){moved=false;return}const c=e.target.closest('.cat-card');if(!c)return;const k=c.dataset.cat;location.href='flavors.html'+(k!=='all'?'?cat='+encodeURIComponent(k):'')});
}
})();


/* ===== Member / Dealer registration + footer year ===== */
(function(){var y=document.getElementById('yr');if(y)y.textContent=new Date().getFullYear();})();
var memberType='customer';
function setMemberType(t){
  memberType=t;
  document.querySelectorAll('.mb-tab').forEach(function(b){b.classList.toggle('active',b.dataset.t===t);});
  document.querySelectorAll('.dealer-only').forEach(function(e){e.style.display=(t==='dealer')?'block':'none';});
}
function submitMember(){
  var v=function(id){return (document.getElementById(id).value||'').trim();};
  var name=v('mbName'), city=v('mbCity'), em=v('mbEmail');
  var ph=v('mbPhone').replace(/[\s\-+]/g,'').replace(/^91(?=\d{10}$)/,'');
  var shop=v('mbShop'), gst=v('mbGst').toUpperCase(), fssai=v('mbFssai').replace(/\s/g,'');
  if(!name||!city){showToast('⚠️ कृपया नाम और गाँव/शहर भरें','error');return;}
  if(!/^[6-9]\d{9}$/.test(ph)){showToast('⚠️ सही 10 अंकों का मोबाइल नंबर डालें','error');return;}
  if(em&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)){showToast('⚠️ Email सही नहीं है','error');return;}
  if(memberType==='dealer'){
    if(!shop){showToast('⚠️ कृपया दुकान / फर्म का नाम भरें','error');return;}
    if(gst&&!/^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]$/.test(gst)){showToast('⚠️ GSTIN सही नहीं है','error');return;}
    if(fssai&&!/^\d{14}$/.test(fssai)){showToast('⚠️ FSSAI नंबर 14 अंकों का होना चाहिए','error');return;}
  }
  if(!document.getElementById('mbConsent').checked){showToast('⚠️ Privacy Policy और Terms पर सहमति दें','error');return;}
  var msg='SF Soda / Shital Foods — '+(memberType==='dealer'?'Dealer / Distributor Registration':'Customer Member Registration')
    +'\nName: '+name+'\nMobile: '+ph+'\nVillage/City: '+city
    +(em?'\nEmail: '+em:'')
    +(memberType==='dealer'?'\nShop/Firm: '+shop+(gst?'\nGSTIN: '+gst:'')+(fssai?'\nFSSAI: '+fssai:''):'')
    +'\nConsent: I agree to the Privacy Policy and Terms & Conditions.';
  window.open('https://wa.me/919764026807?text='+encodeURIComponent(msg),'_blank');
  showToast('📱 WhatsApp खुल रहा है — Send दबाएँ','success');
}

/* flavors.html?cat=fruit -> open that filter */
(function(){const c=new URLSearchParams(location.search).get('cat');if(!c||!document.getElementById('allFlavors'))return;const b=[...document.querySelectorAll('.ffilter')].find(x=>(x.getAttribute('onclick')||'').includes("'"+c+"'"));if(b)b.click()})();
